#!/usr/bin/env bash
# Setup script for:
# 1. Installing depencies
# 2. Loading categories data

npm install && npm run load-data
