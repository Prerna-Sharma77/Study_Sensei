# Course Finder Scraper
Simple web scraper

## Getting Started
Run setup script
```
./setup.sh
```

Start scraper
```
npm run start-scraper
```

## Logs
- Logs directories created on start up.
- Scraper logs available in `scraper/logs` directory.
